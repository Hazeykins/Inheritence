
package inheritence;


public class Inheritence {

    
    public static void main(String[] args) {
        Person p = new Person(19, "Ben", "Ahmadi", "07364 123456", "Dark Brown", 6.7, "Male");
        
        System.out.println(p);
        
    }
    
}
