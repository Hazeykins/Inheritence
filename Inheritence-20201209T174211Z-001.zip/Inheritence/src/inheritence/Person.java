
package inheritence;


public class Person {
    
    private int age;
    private String firstName;
    private String secondName;
    private String mobile;
    private String hairColour;
    private double height;
    private String gender;

    public Person(int age, String firstName, String secondName, String mobile, String hairColour, double height, String gender) {
        this.age = age;
        this.firstName = firstName;
        this.secondName = secondName;
        this.mobile = mobile;
        this.hairColour = hairColour;
        this.height = height;
        this.gender = gender;
    }

    @Override
    public String toString() {
        return "Person{" + "\nage=" + age + ", \nfirstName=" + firstName + ", \nsecondName=" + secondName + ", \nmobile=" + mobile + ", \nhairColour=" + hairColour + ", \nheight=" + height + ", \ngender=" + gender + '}';
    }
    
    
    
   
    
    
}
